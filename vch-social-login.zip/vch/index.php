<?php 
  session_start();
  require_once 'header.php';

  echo "<div class='center'>Valley Children's Hospital,";

  if ($loggedin) echo " $user, you are logged in";
  else           echo ' please sign up or log in';

  echo <<<_END
      </div><br>
    </div>
    <div data-role="footer">
      <h4>Educational Purposes - CSE 120</h4>
    </div>
  </body>
</html>
_END;
?>
